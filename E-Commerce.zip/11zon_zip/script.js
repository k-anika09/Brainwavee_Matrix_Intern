let cart = [];

function addToCart(productName, productPrice) {
    cart.push({ name: productName, price: productPrice });
    updateCart();
    toggleCart(); // Automatically open the cart when a product is added
}

function updateCart() {
    const cartItems = document.getElementById('cart-items');
    cartItems.innerHTML = '';
    let total = 0;

    cart.forEach((item, index) => {
        total += item.price;
        cartItems.innerHTML += `<p>Rs.{item.name} - $${item.price.toFixed(2)} <button onclick="removeFromCart(${index})">Remove</button></p>`;
    });

    document.getElementById('cart-total').innerText = total.toFixed(2);
}

function removeFromCart(index) {
    cart.splice(index, 1);
    updateCart();
}

function toggleCart() {
    const cartModal = document.getElementById('cart-modal');
    cartModal.style.display = cartModal.style.display === "block" ? "none" : "block";
}

function showSection(section) {
    document.querySelectorAll('section').forEach(s => s.classList.remove('active-section'));
    document.getElementById(section).classList.add('active-section');
}

window.onclick = function(event) {
    const cartModal = document.getElementById('cart-modal');
    if (event.target === cartModal) {
        cartModal.style.display = "none";
    }
}
